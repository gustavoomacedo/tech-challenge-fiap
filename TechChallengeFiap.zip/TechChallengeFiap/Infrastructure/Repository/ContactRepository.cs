﻿namespace TechChallengeFiap.Infrastructure.Repository
{
    public class ContactRepository
    {
    }
}
