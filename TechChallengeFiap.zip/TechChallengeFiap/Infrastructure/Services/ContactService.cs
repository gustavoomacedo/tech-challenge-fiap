﻿using TechChallengeFiap.Interfaces;
using TechChallengeFiap.Models;

namespace TechChallengeFiap.Infrastructure.Services
{
    public class ContactService : IContactService
    {
        public Contact AddContact(Contact contact)
        {
            throw new NotImplementedException();
        }
    }
}
