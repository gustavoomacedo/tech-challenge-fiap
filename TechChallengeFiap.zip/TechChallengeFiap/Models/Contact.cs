﻿namespace TechChallengeFiap.Models
{
    public class Contact
    {
        public required string Nome { get; set; }
        public required string DDD { get; set; }
        public required string Telefone { get; set; }
        public required string Email { get; set; }

    }
}
